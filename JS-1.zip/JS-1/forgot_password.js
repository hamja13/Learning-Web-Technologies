// forgot_password.js
function validateForm() {
     // Retrieve form input values
     var email = document.getElementById('fp-email').value;
     var phone = document.getElementById('fp-phone').value;
     var password = document.getElementById('fp-password').value;
     var confirmPassword = document.getElementById('fp-cpassword').value;

     // Simple email validation (you can improve it with a regular expression)
     if (email === "") {
         alert("Please enter your email.");
         return false;
     }

     // Simple phone validation (you can improve it with a regular expression)
     if (phone === "") {
         alert("Please enter your phone number.");
         return false;
     }

     // Simple password validation
     if (password === "") {
         alert("Please enter your password.");
         return false;
     }

     // Check if password and confirm password match
     if (password !== confirmPassword) {
         alert("Passwords do not match.");
         return false;
     }

     return true; // Submit the form if validation passes
}
