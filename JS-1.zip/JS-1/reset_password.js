// reset_password.js
function validateForm() {
     // Retrieve form input values
     var oldPassword = document.getElementById('rp-old-password').value;
     var newPassword = document.getElementById('rp-new-password').value;
     var confirmNewPassword = document.getElementById('rp-new-cpassword').value;

     // Simple old password validation
     if (oldPassword === "") {
         alert("Please enter your old password.");
         return false;
     }

     // Simple new password validation
     if (newPassword === "") {
         alert("Please enter your new password.");
         return false;
     }

     // Check if the new password and confirm new password match
     if (newPassword !== confirmNewPassword) {
         alert("New passwords do not match.");
         return false;
     }

     return true; // Submit the form if validation passes
}
