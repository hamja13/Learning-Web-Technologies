<?php
require('db.php');
if(isset($_POST['signup'])){
    $query="SELECT * FROM user WHERE email_id='{$_POST['emailid']}'";
    $run =mysqli_query($db,$query);
    $data=mysqli_fetch_array($run);
    if(count($data)>0){
        echo "<script>window.location.href='signup.php?user_already_signedup';</script>";
    }else{
        $query="INSERT INTO user (full_name,email_id,password,role)";

        $query.="VALUES ('{$_POST['fullname']}','{$_POST['emailid']}','{$_POST['password']}','user')";

    $run = mysqli_query($db,$query);
    if($run){
        echo "<script>window.location.href='signup.php?user_successfully_signedup';</script>";
    }

    }
}
?>




<html>
<head>
     <title> Signup  </title>
</head>
<body>
     <center>
         <?php
         include_once 'header.php';
         ?>
         <h1> Create Account </h1>

         <form action="" method="post" onsubmit="return validateForm()">
             <label for="signup-name"> Name: </label> <input type="text" name="signup-name" id="signup-name"><br>
             <label for="signup-email"> Email: </label> <input type="text" name="signup-email" id="signup-email"><br>
             <label for="signup-phone"> Phone: </label> <input type="text" name="signup-phone" id="signup-phone"><br>
             <label for="signup-address"> Address: </label> <input type="text" name="signup-address" id="signup-address"><br>
             <label for="signup-password"> Enter password: </label> <input type="password" name="signup-password" id="signup-password"><br>
             <label for="signup-password"> Confirm password: </label> <input type="password" name="signup-cpassword" id="signup-cpassword"><br>
             <button type="submit"> Signup</button> | <button type="reset"> Clear </button>
         </form>
     </center>

     <script src="path/to/signup.js"></script>
</body>
</html>
