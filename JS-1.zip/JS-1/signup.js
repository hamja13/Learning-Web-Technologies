//signup.js
function validateForm() {
     // Retrieve form input values
     var name = document.getElementById('signup-name').value;
     var email = document.getElementById('signup-email').value;
     var phone = document.getElementById('signup-phone').value;
     var address = document.getElementById('signup-address').value;
     var password = document.getElementById('signup-password').value;
     var confirmPassword = document.getElementById('signup-cpassword').value;

     // Simple name validation
     if (name === "") {
         alert("Please enter your name.");
         return false;
     }

     // Simple email validation (you can improve it with a regular expression)
     if (email === "") {
         alert("Please enter your email.");
         return false;
     }

     // Simple phone validation (you can improve it with a regular expression)
     if (phone === "") {
         alert("Please enter your phone number.");
         return false;
     }

     // Simple address validation
     if (address === "") {
         alert("Please enter your address.");
         return false;
     }

     // Simple password validation
     if (password === "") {
         alert("Please enter your password.");
         return false;
     }

     // Check if password and confirm password match
     if (password !== confirmPassword) {
         alert("Passwords do not match.");
         return false;
     }

     return true; // Submit the form if validation passes
}