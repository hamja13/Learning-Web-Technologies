// login.js
function validateForm() {
     // Retrieve form input values
     var email = document.getElementById('login-email').value;
     var password = document.getElementById('login-password').value;

     // Simple email validation (you can improve it with a regular expression)
     if (email === "") {
         alert("Please enter your email.");
         return false;
     }

     // Simple password validation
     if (password === "") {
         ("Please enter your password.");
         return false;
     }

     return true; // Submit the form if validation passes
}
