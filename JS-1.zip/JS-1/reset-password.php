<html>
<head>
     <title>Reset Password</title>
</head>
<body>
     <center>
         <?php
         include_once 'header.php';
         ?>
         <form action="" method="post" onsubmit="return validateForm()">
             <label for="rp-old-password">Enter password:</label> <input type="password" name="rp-old-password" id="rp-old-password"><br>
             <label for="rp-new-password">Enter password:</label> <input type="password" name="rp-new-password" id="rp-new-password"><br>
             <label for="rp-new-cpassword">Confirm password:</label> <input type="password" name="rp-new-cpassword" id="rp-new-cpassword"><br>
             <button type="submit"> Reset Password</button>|<button type="reset">Clear </button>
         </form>

     </center>

     <script src="path/to/reset_password.js"></script>
</body>
</html>
