<?php
require('db.php');
if(isset($_SESSION['isUserLoggedIn'])){

        if($_SESSION['role']=="user"){
    
            echo "<script>window.location.href='user.php?user_successfully_logedin';</script>";
        }

        if($_SESSION['role']=="admin"){
    
            echo "<script>window.location.href='admin.php?user_successfully_logedin';</script>";
            }
}
if(isset($_POST['login'])){
    $query="SELECT * FROM user WHERE email_id='{$_POST['emailid']}' AND password='{$_POST['password']}'";
    $run =mysqli_query($db,$query);
    $data=mysqli_fetch_array($run);
    if(count($data)>0){
        
        $_SESSION['isUserLoggedIn']=true;
        $_SESSION['emailId']=$_POST['emailid'];
        $_SESSION['role']=$data['role'];
        if($_data['role']=="user"){
    
        echo "<script>window.location.href='user.php?user_successfully_logedin';</script>";
        }

        if($_data['role']=="admin"){
    
            echo "<script>window.location.href='admin.php?user_successfully_logedin';</script>";
            }

    }else{
        echo "<script>window.location.href='user.php?incorrect_email_or_password';</script>";
    }
   
}
?>




<html>
<head>
    <title>Log in</title>
</head>
<body>
    <center>
        <?php
        include_once 'header.php';
        ?>
        <form action="" method="post" onsubmit="return validateForm()">
            <label for="login-email"> Email: </label> <input type="email" name="emailid" id="login-email" required><br>
            <label for="login-password"> Password: </label> <input type="password" name="login-password" id="login-password" required><br>
            <button type="submit"> Login </button>|<button type="reset"> Clear </button><br>
            <a href="forgot-password.php">Forgot Password?</a>
        </form>
    </center>

    <script src="path/to/login.js"></script>
</body>
</html>