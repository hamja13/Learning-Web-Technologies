<html>
<head>
     <title> Forgot Password </title>
</head>
<body>
     <center>
         <?php
         include_once 'header.php';
         ?>
         <form action="" method="post" onsubmit="return validateForm()">
             <label for="fp-email"> Email: </label> <input type="email" name="fp-email" id="fp-email"><br>
             <label for="fp-phone"> Phone: </label> <input type="text" name="fp-phone" id="fp-phone"><br>
             <label for="fp-password"> Enter Password: </label> <input type="password" name="fp-password" id="fp-password"><br>
             <label for="fp-password"> Confirm Password: </label> <input type="password" name="fp-cpassword" id="fp-cpassword"><br>
             <button type="submit"> Reset Password </button>|<button type="reset"> Clear </button>
         </form>
     </center>

     <script src="path/to/forgot_password.js"></script>
</body>
</html>